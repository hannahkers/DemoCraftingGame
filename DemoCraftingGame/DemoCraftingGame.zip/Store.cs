﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCraftingGame
{
    public class DyeStore
    {
        public string Name;

        public List<Item> Inventory;

        public void sell()
        {
            throw new System.NotImplementedException();
        }
    }
}