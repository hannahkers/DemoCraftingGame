﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCraftingGame
{
    public class Item
    {
        public string Name;
        public string Description;
        public float Quantity;
        public Recipe CraftingRecipe;
        public float Price;

    }
}