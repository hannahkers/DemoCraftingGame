﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCraftingGame
{
    public class CraftingStation : Item
    {

        public CraftingStation()
        {
            Name = "Crafting Station";

        }

        public void MakePotionFromRecipe()
        {
            foreach()
            {

            }
        }
    }
}