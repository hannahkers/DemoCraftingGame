﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;
using static DemoCraftingGame.Utility;

namespace DemoCraftingGame
{
    public class Game
    {
        Person Player = new Person();
        NPC Trader = new NPC();
        public void Run()
        {
            SetUpGame();
            ShowWelcome();

            Print("This is what is in your inventory...");
            Print(ShowAllItemsInList(Player.Inventory));
            //Utility.Pause();
            Pause();
            Print("This is what our NPC has...");
            Print(ShowAllItemsInList(Trader.Inventory));
            Pause();
            MakePurchase();
            Pause();

            
        }
        public void MakePurchase()
        {
            Print("Would you like to make a purchase today?");

        }

        private void SetUpGame()
        {
            
            Player.Name = "Anonymous Player";

            Title = "Crafting System Demo!";

        }

        private void ShowWelcome()
        {
            //concatenation
            //WriteLine("Welcome " + Player.Name);

            //composite formatting
            //WriteLine("Welcome {0}", Player.Name);

            //interpolation formatting
            //WriteLine($"Welcome {Player.Name}");

            //greet player and get name
            Print("Welcome Player! What would you like to be called?");
            Player.Name = ReadLine();
            Print($"Welcome {Player.Name}");
            
          
        }
    }

    
}