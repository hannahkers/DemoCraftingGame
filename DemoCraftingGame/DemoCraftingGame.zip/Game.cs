﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;
using static DemoCraftingGame.Utility;

namespace DemoCraftingGame
{
    public class Game
    {
        public void Run()
        {

            Person Player = new Person();
            Player.Name = "Anonymous Player";

            Title = "Crafting System Demo!";
            //concatenation
            //WriteLine("Welcome " + Player.Name);

            //composite formatting
            //WriteLine("Welcome {0}", Player.Name);

            //interpolation formatting
            //WriteLine($"Welcome {Player.Name}");

            //greet player and get name
            WriteLine("Welcome Player! What would you like to be called?");
            Player.Name = ReadLine();
            Pause();

            //interpolation formatting
            WriteLine($"Welcome {Player.Name}");
            Pause();






            Item redDye = new Item();
            redDye.Price = 3.5f;
            redDye.Name = "Red Dye";
            WriteLine($"{redDye.Name} is {redDye.Price.ToString("c")} per vial.");

            Item blueDye = new Item();
            blueDye.Price = 2.5f;
            blueDye.Name = "Blue Dye";
            WriteLine($"{blueDye.Name} is {blueDye.Price.ToString("c")} per vial.");

            //Utility.Pause();
            Pause();
        }
    }
}