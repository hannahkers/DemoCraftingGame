﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoCraftingGame
{
    public class Recipe
    {
        public string Name;
        public string Description;
        public List<Item> Ingredients = new List<Item>();

        Recipe HealthPotion = new Recipe();




    }
}
//potions
//health, stamina, transformation, defense, flying, love, power up, mana, invisibility, underwater breathing, fire, defense