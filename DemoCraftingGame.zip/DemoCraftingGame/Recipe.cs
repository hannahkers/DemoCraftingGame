﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;
using static DemoCraftingGame.Utility;
using static DemoCraftingGame.Utilities.LoadExternalData;

namespace DemoCraftingGame
{
    public class Recipe
    {
        public string Name;
        public string Description;
        public List<Item> Ingredients = new List<Item>();

        





    }
}
//potions
//health, stamina, transformation, defense, flying, love, power up, mana, invisibility, underwater breathing, fire, defense, sleeping